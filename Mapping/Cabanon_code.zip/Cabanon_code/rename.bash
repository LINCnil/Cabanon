for i in `seq 2 9`;
   do
      mv "yellow_tripdata_2013-0"$i".csv"  "yellow_tripdata_2013-"$i".csv" 
   done    
